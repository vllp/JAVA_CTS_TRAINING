package com.cts.spring.boot.data.jpa.demo2.service;

import java.util.List;

import com.cts.spring.boot.data.jpa.demo2.entity.Employee;

public interface EmployeeService {

	Employee getById(Long id);

	List<Employee> getAll();

	Employee add(Employee txn);

	void remove(Long id);
}
