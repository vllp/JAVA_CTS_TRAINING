package com.cts.jpahibernatedemo.entity;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
/*
 * @Table(name = "all_trainers")
 * 
 * @Inheritance(strategy = InheritanceType.SINGLE_TABLE)
 * 
 * @DiscriminatorColumn(name = "trianer_type", discriminatorType =
 * DiscriminatorType.STRING)
 * 
 * @DiscriminatorValue("trianer")
 */

/*
 * @Table(name="trianers")
 * 
 * @Inheritance(strategy = InheritanceType.JOINED)
 */


@Table(name="trainers_only")
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class Trainer {
	@Id
	private Long trainerId;
	private String fullName;
	@Embedded
	private Address address;
	private String skill;
	private Double salary;

	public Trainer() {

	}

	@Override
	public String toString() {
		return "Trainer [trainerId=" + trainerId + ", fullName=" + fullName + ", address=" + address + ", skill="
				+ skill + ", salary=" + salary + "]";
	}

	public Trainer(Long trainerId, String fullName, Address address, String skill, Double salary) {
		super();
		this.trainerId = trainerId;
		this.fullName = fullName;
		this.address = address;
		this.skill = skill;
		this.salary = salary;
	}

	public Long getTrainerId() {
		return trainerId;
	}

	public void setTrainerId(Long trainerId) {
		this.trainerId = trainerId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

}
