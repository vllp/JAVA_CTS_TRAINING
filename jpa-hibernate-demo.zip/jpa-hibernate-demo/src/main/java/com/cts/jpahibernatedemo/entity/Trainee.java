package com.cts.jpahibernatedemo.entity;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "trainees")
public class Trainee implements Comparable<Trainee>{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long traineeId;
	private String traineeName;
	
	@Enumerated(EnumType.STRING)
	private Gender gender;
	
	@Embedded
	private Address traineeAddress;

	@OneToOne(cascade = CascadeType.ALL,mappedBy = "owner")
	private LabComputer computer;
	
	@ManyToOne
	private Course course;

	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName=" + traineeName + ", gender=" + gender
				+ ", traineeAddress=" + traineeAddress + ", computer=" + computer + ", course=" + course + "]";
	}

	public Trainee(Long traineeId, String traineeName, Gender gender, Address traineeAddress, LabComputer computer,
			Course course) {
		super();
		this.traineeId = traineeId;
		this.traineeName = traineeName;
		this.gender = gender;
		this.traineeAddress = traineeAddress;
		this.computer = computer;
		this.setCourse(course);
	}

	public Long getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(Long traineeId) {
		this.traineeId = traineeId;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public Address getTraineeAddress() {
		return traineeAddress;
	}

	public void setTraineeAddress(Address traineeAddress) {
		this.traineeAddress = traineeAddress;
	}

	public LabComputer getComputer() {
		return computer;
	}

	public void setComputer(LabComputer computer) {
		this.computer = computer;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	@Override
	public int compareTo(Trainee arg0) {
		return this.traineeId == null? -1 : this.traineeId.compareTo(arg0.traineeId);
	}

}
