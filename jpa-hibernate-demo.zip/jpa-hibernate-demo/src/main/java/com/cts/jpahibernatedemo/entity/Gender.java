package com.cts.jpahibernatedemo.entity;

public enum Gender {
	
	GENT,LADY;

}




