package com.cts.jpahibernatedemo.entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
//@DiscriminatorValue("Ach_head")

//@Table(name="ah_trainers")

@Table(name="ah_trainers_only")
public class AcademicHead extends Trainer {
	private Double allowance;

	public AcademicHead() {
	}

	@Override
	public String toString() {
		return "AcademicHead [allowance=" + allowance + "]";
	}

	public Double getAllowance() {
		return allowance;
	}

	public void setAllowance(Double allowance) {
		this.allowance = allowance;
	}

	public AcademicHead(Long trainerId, String fullName, Address address, String skill, Double salary,
			Double allowance) {
		super(trainerId, fullName, address, skill, salary);
		this.allowance = allowance;
	}

}
