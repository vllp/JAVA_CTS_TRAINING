package com.cts.spring.boot.rest.api.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.spring.boot.rest.api.dto.PatientDto;
import com.cts.spring.boot.rest.api.entity.Patient;
import com.cts.spring.boot.rest.api.repos.PatientRepo;

@Service
public class PatientServiceAPIImpl implements PatientServiceAPI {

	@Autowired
	PatientRepo patientRepo;

	@Override
	public Patient getPatient(Long patientId) {
		return patientRepo.findById(patientId).orElse(null);
	}

	@Override
	public List<Patient> getAllPatients() {
		return patientRepo.findAll();
	}

	@Override
	public Patient create(PatientDto pdto) {
		Patient pat = new Patient();
		pat.setFirstName(pdto.getFirstName());
		pat.setLastName(pdto.getLastName());
		pat.setAge(pdto.getAge());
		return patientRepo.save(pat);
	}

	@Transactional
	@Override
	public Patient update(Long patientId, PatientDto pdto) {
		Patient oldPatient = patientRepo.findById(patientId).orElse(null);
		oldPatient.setFirstName(pdto.getFirstName());
		oldPatient.setLastName(pdto.getLastName());
		oldPatient.setAge(pdto.getAge());
		//patientRepo.save(oldPatient);
		return patientRepo.save(oldPatient);
	}

	@Override
	public void delete(Long patientId) {
		patientRepo.deleteById(patientId);

	}

}
