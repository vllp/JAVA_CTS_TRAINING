package com.cts.jsedemo.streams;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.function.ToDoubleFunction;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class EmployeeTransactionImpl {

	public static void main(String[] args) {
		List<EmployeeTransaction> et = new ArrayList<>();
		et.add(new EmployeeTransaction(1, "Rent", 10000, LocalDate.of(2022, Month.JANUARY, 1), "DEBIT"));
		et.add(new EmployeeTransaction(2, "Salary", 70000, LocalDate.of(2022, Month.FEBRUARY, 1), "CREDIT"));
		et.add(new EmployeeTransaction(3, "Shopping", 15000, LocalDate.of(2022, Month.FEBRUARY, 10), "DEBIT"));
		et.add(new EmployeeTransaction(4, "Fee", 10000, LocalDate.of(2022, Month.FEBRUARY, 11), "DEBIT"));
		et.add(new EmployeeTransaction(5, "Transfer", 10000, LocalDate.of(2022, Month.MARCH, 11), "CREDIT"));
		et.add(new EmployeeTransaction(6, "Rent", 10000, LocalDate.of(2022, Month.FEBRUARY, 11), "DEBIT"));
		et.add(new EmployeeTransaction(7, "Shopping", 10000, LocalDate.of(2022, Month.FEBRUARY, 13), "DEBIT"));
		et.add(new EmployeeTransaction(8, "Transfer", 10000, LocalDate.of(2022, Month.MARCH, 11), "CREDIT"));
		et.add(new EmployeeTransaction(9, "Fee", 10000, LocalDate.of(2022, Month.MARCH, 1), "DEBIT"));
		et.add(new EmployeeTransaction(10, "Transfer", 10000, LocalDate.of(2022, Month.MARCH, 11), "CREDIT"));
		System.out.println("SIZE OF LIST :" + et.size());
		/*
		 * for (EmployeeTransaction e : et) { System.out.println(e.toString()); }
		 */
		System.out.println("1---------------");

		et.stream().forEach(System.out::println);
		System.out.println("2---------------");
		et.stream().forEach(e -> System.out.println(e));
		System.out.println("3---------------");

		Double totalCredits = et.stream().filter(e -> e.getTransType().matches("CREDIT"))
				.mapToDouble(EmployeeTransaction::getTransAmount).sum();
		System.out.println("Total credits :" + totalCredits);
		Double totalDebits = et.stream().filter(e -> e.getTransType().matches("DEBIT"))
				.mapToDouble(EmployeeTransaction::getTransAmount).sum();
		System.out.println("Total debits :" + totalDebits);
		Double balance = totalCredits - totalDebits;
		System.out.println("Balance ::" + balance);
		/*
		 * = et.stream().filter(e -> e.getTransType().matches("DEBIT"))
		 * .mapToDouble(EmployeeTransaction::getTransAmount).sum();
		 */

		//Double totalDebits = et.stream().reduce(null)
	}

}
