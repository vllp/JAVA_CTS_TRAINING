package com.cts.spring.boot.data.jpa.demo2.entity;

import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long empId;
	private String empName;
	private LocalDate joinDate;
	private double empSal;
	private String empDesig;

	public Employee() {
	}

	@Override
	public int hashCode() {
		return Objects.hash(empDesig, empId, empName, empSal, joinDate);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return Objects.equals(empDesig, other.empDesig) && empId == other.empId
				&& Objects.equals(empName, other.empName)
				&& Double.doubleToLongBits(empSal) == Double.doubleToLongBits(other.empSal)
				&& Objects.equals(joinDate, other.joinDate);
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", joinDate=" + joinDate + ", empSal=" + empSal
				+ ", empDesig=" + empDesig + "]";
	}

	public Employee(long empId, String empName, LocalDate joinDate, double empSal, String empDesig) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.joinDate = joinDate;
		this.empSal = empSal;
		this.empDesig = empDesig;
	}

	public long getEmpId() {
		return empId;
	}

	public void setEmpId(long empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public LocalDate getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(LocalDate joinDate) {
		this.joinDate = joinDate;
	}

	public double getEmpSal() {
		return empSal;
	}

	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}

	public String getEmpDesig() {
		return empDesig;
	}

	public void setEmpDesig(String empDesig) {
		this.empDesig = empDesig;
	}

}
