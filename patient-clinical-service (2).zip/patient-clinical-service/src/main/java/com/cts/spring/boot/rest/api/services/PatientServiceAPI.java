package com.cts.spring.boot.rest.api.services;

import java.util.List;

import com.cts.spring.boot.rest.api.dto.PatientDto;
import com.cts.spring.boot.rest.api.entity.Patient;

public interface PatientServiceAPI {

	Patient getPatient(Long patientId);// getById

	List<Patient> getAllPatients();// getAll

	Patient create(PatientDto patient);// add

	Patient update(Long pId, PatientDto patient);// save

	void delete(Long patientId);// remove

}
