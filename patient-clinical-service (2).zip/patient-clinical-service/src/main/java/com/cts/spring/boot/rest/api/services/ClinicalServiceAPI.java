package com.cts.spring.boot.rest.api.services;

import java.util.List;

import com.cts.spring.boot.rest.api.dto.ClinicalDetailsDto;
import com.cts.spring.boot.rest.api.entity.ClinicalDetails;
import com.cts.spring.boot.rest.api.entity.Patient;

public interface ClinicalServiceAPI {

	List<ClinicalDetails> getClinicalByPatId(Long patientId);// getById

	ClinicalDetails createClinical(Long patientId,ClinicalDetailsDto cdto);// add

	ClinicalDetails updateClinicalByPatId(Long pId, ClinicalDetails clinicalDetails,Patient p);// save

}
