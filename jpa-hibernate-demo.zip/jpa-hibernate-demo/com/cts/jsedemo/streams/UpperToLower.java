package com.cts.jsedemo.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class UpperToLower {

	public static void main(String[] args) {
		List<String> l1 = new ArrayList<>();
		l1.add("AAA");
		l1.add("BBB");
		System.out.println("List l1 :::"+l1);
		List l2=l1.stream().map(s->s.toLowerCase()).collect(Collectors.toList());
		System.out.println("List l2 :::"+l2);
		
		
	}

}
