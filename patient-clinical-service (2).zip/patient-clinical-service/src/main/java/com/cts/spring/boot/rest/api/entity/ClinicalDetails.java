package com.cts.spring.boot.rest.api.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="clinical")
public class ClinicalDetails{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long clinicalId;
	//@Enumerated(EnumType.STRING)
	
	@NotBlank(message = "This field is mandate")
	@Size(min = 1,max = 20,message = "A minimum of 1 and a maximum of 20 chars expected")
	private String componentName;
	
	@NotNull (message="This field is mandate")
	@Min(value = 1,message = "Zero or Negative valeus not expected")
	private double componentValue;
	
	@PastOrPresent(message = "Entered date can not be of future")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate measuredDateTime;
	
	@ManyToOne(fetch = FetchType.LAZY)
	//@JsonProperty(access = Access.WRITE_ONLY)
	@JoinColumn(name="patientId",referencedColumnName = "patientId")
	private Patient patient;
	
	public Long getClinicalId() {
		return clinicalId;
	}
	public void setClinicalId(Long clinicalId) {
		this.clinicalId = clinicalId;
	}
	public String getComponentName() {
		return componentName;
	}
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}
	public double getComponentValue() {
		return componentValue;
	}
	public void setComponentValue(double componentValue) {
		this.componentValue = componentValue;
	}
	public LocalDate getMeasuredDateTime() {
		return measuredDateTime;
	}
	public void setMeasuredDateTime(LocalDate measuredDateTime) {
		this.measuredDateTime = measuredDateTime;
	}
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	@Override
	public String toString() {
		return "ClinicalDetails [clinicalId=" + clinicalId + ", componentName=" + componentName + ", componentValue="
				+ componentValue + ", measuredDateTime=" + measuredDateTime + ", patient=" + patient + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(clinicalId);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ClinicalDetails other = (ClinicalDetails) obj;
		return Objects.equals(clinicalId, other.clinicalId) && componentName == other.componentName
				&& Double.doubleToLongBits(componentValue) == Double.doubleToLongBits(other.componentValue)
				&& Objects.equals(measuredDateTime, other.measuredDateTime) && Objects.equals(patient, other.patient);
	}
	public ClinicalDetails(Long clinicalId, String componentName, double componentValue,
			@PastOrPresent(message = "Entered date can not be of future") LocalDate measuredDateTime, Patient patient) {
		super();
		this.clinicalId = clinicalId;
		this.componentName = componentName;
		this.componentValue = componentValue;
		this.measuredDateTime = measuredDateTime;
		this.patient = patient;
	}
	public ClinicalDetails() {
	}
	
	

}
