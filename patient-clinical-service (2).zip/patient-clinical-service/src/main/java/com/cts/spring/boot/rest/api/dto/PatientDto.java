package com.cts.spring.boot.rest.api.dto;

import java.util.Set;

import com.cts.spring.boot.rest.api.entity.ClinicalDetails;

public class PatientDto {

	private Long patientId;
	private String firstName;
	private String lastName;
	private Long age;
	private Set<ClinicalDetails> clinicalDetails;

	public PatientDto() {
	}

	public PatientDto(Long patientId, String firstName, String lastName, Long age,
			Set<ClinicalDetails> clinicalDetails) {
		super();
		this.patientId = patientId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.clinicalDetails = clinicalDetails;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Long getAge() {
		return age;
	}

	public void setAge(Long age) {
		this.age = age;
	}

	public Set<ClinicalDetails> getClinicalDetails() {
		return clinicalDetails;
	}

	public void setClinicalDetails(Set<ClinicalDetails> clinicalDetails) {
		this.clinicalDetails = clinicalDetails;
	}

}
