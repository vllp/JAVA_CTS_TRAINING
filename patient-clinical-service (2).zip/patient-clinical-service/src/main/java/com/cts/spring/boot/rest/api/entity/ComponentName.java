package com.cts.spring.boot.rest.api.entity;

public enum ComponentName {
	HEIGHT, WEIGHT, BMI;
}
