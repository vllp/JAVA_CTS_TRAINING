package com.cts.jpahibernatedemo.ui;

import java.util.TreeSet;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cts.jpahibernatedemo.entity.Address;
import com.cts.jpahibernatedemo.entity.Course;
import com.cts.jpahibernatedemo.entity.Gender;
import com.cts.jpahibernatedemo.entity.LabComputer;
import com.cts.jpahibernatedemo.entity.Trainee;

public class AppImplAssociation {

	public static void main(String args[]) {

		Course c1 = new Course(null, "Java", new TreeSet<>());
		Course c2 = new Course(null, ".Net", new TreeSet<>());

		Trainee t1 = new Trainee(null, "Lalitha", Gender.LADY, new Address("flat1", "BZA", "AP"), null, c1);
		t1.setComputer(new LabComputer(null, "1GB ram", t1));
		Trainee t2 = new Trainee(null, "Manju", Gender.LADY, new Address("flat11", "TDP", "AP"), null, c1);
		t2.setComputer(new LabComputer(null, "1GB ram", t2));
		Trainee t3 = new Trainee(null, "Avik", Gender.GENT, new Address("flat13", "GUN", "AP"), null, c2);
		t3.setComputer(new LabComputer(null, "1GB ram", t3));
		Trainee t4 = new Trainee(null, "Suma", Gender.LADY, new Address("flat101", "BZA", "AP"), null, c2);
		t4.setComputer(new LabComputer(null, "1GB ram", t4));
		Trainee t5 = new Trainee(null, "Hari", Gender.LADY, new Address("flat1333", "BZA", "AP"), null, c1);
		t5.setComputer(new LabComputer(null, "1GB ram", t5));

		c1.getTrainee().add(t1);
		c1.getTrainee().add(t2);
		c2.getTrainee().add(t3);
		c2.getTrainee().add(t4);
		c2.getTrainee().add(t5);
		EntityManager em = Persistence.createEntityManagerFactory("mysqlPU").createEntityManager();
		EntityTransaction et = em.getTransaction();

		et.begin();
		em.persist(c1);
		em.persist(c2);
		et.commit();
		em.clear();

	}
}
