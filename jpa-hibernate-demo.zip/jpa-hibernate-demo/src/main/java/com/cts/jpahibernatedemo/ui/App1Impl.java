package com.cts.jpahibernatedemo.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cts.jpahibernatedemo.entity.Course;

public class App1Impl {

	public static void main(String args[]) {
		Course[] courses = new Course[] { new Course(null, "JavaSE",null), new Course(null, "Hibernate JPA",null),
				new Course(null, "Spring Core",null), new Course(null, "Spring Web",null), new Course(null, "Spring REST",null) };

		EntityManager em = Persistence.createEntityManagerFactory("mysqlPU").createEntityManager();
		EntityTransaction et = em.getTransaction();

		et.begin();
		for (Course c : courses) {
			em.persist(c);
		}
		et.commit();
		em.clear();

	}
}
