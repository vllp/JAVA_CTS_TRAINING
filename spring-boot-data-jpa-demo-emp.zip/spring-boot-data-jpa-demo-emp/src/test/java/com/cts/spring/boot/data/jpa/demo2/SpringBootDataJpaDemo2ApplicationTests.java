package com.cts.spring.boot.data.jpa.demo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDataJpaDemo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
