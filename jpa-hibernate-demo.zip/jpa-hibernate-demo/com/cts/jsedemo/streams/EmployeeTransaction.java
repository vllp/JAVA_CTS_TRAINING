package com.cts.jsedemo.streams;

import java.time.LocalDate;

public class EmployeeTransaction {

	@Override
	public String toString() {
		return "EmployeeTransaction [transId=" + transId + ", transDesc=" + transDesc + ", transAmount=" + transAmount
				+ ", transDate=" + transDate + ", transType=" + transType + "]";
	}

	private int transId;
	private String transDesc;
	private double transAmount;
	private LocalDate transDate;
	private String transType;

	public EmployeeTransaction(int transId, String transDesc, double transAmount, LocalDate transDate,
			String transType) {
		super();
		this.transId = transId;
		this.transDesc = transDesc;
		this.transAmount = transAmount;
		this.transDate = transDate;
		this.transType = transType;
	}

	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}

	public String getTransDesc() {
		return transDesc;
	}

	public void setTransDesc(String transDesc) {
		this.transDesc = transDesc;
	}

	public double getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(double transAmount) {
		this.transAmount = transAmount;
	}

	public LocalDate getTransDate() {
		return transDate;
	}

	public void setTransDate(LocalDate transDate) {
		this.transDate = transDate;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

}
