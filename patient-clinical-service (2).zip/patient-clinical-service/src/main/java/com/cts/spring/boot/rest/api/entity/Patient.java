package com.cts.spring.boot.rest.api.entity;

import java.io.Serializable;
import java.util.Objects;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "patient")
public class Patient {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long patientId;
	
	@NotBlank(message = "This field is mandate")
	@Size(min = 1,max = 20,message = "A minimum of 4 and a maximum of 20 chars expected")
	private String firstName;
	
	@NotBlank(message = "This field is mandate")
	@Size(min = 1,max = 20,message = "A minimum of 4 and a maximum of 20 chars expected")
	private String lastName;
	
	@NotNull (message="This field is mandate")
	@Min(value = 1,message = "Zero or Negative valeus not expected")
	private Long age;
	
	//@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@OneToMany(mappedBy = "patient",fetch = FetchType.LAZY)
	private Set<ClinicalDetails>  clinicalDetails;
	
	public Patient() {
	}
	public Patient(Long patientId, String firstName, String lastName, Long age, Set<ClinicalDetails> clinicalDetails) {
		super();
		this.patientId = patientId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.clinicalDetails = clinicalDetails;
	}
	public Long getPatientId() {
		return patientId;
	}
	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Long getAge() {
		return age;
	}
	public void setAge(Long age) {
		this.age = age;
	}
	public Set<ClinicalDetails> getClinicalDetails() {
		return clinicalDetails;
	}
	public void setClinicalDetails(Set<ClinicalDetails> clinicalDetails) {
		this.clinicalDetails = clinicalDetails;
	}
	@Override
	public int hashCode() {
		return Objects.hash(age, clinicalDetails, firstName, lastName, patientId);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Patient other = (Patient) obj;
		return Objects.equals(age, other.age) && Objects.equals(clinicalDetails, other.clinicalDetails)
				&& Objects.equals(firstName, other.firstName) && Objects.equals(lastName, other.lastName)
				&& Objects.equals(patientId, other.patientId);
	}
	@Override
	public String toString() {
		return "Patient [patientId=" + patientId + ", firstName=" + firstName + ", lastName=" + lastName + ", age="
				+ age + ", clinicalDetails=" + clinicalDetails + "]";
	}
	
	

}
