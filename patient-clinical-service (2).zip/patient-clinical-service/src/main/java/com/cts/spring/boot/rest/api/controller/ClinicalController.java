package com.cts.spring.boot.rest.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.spring.boot.rest.api.entity.ClinicalDetails;
import com.cts.spring.boot.rest.api.services.ClinicalServiceAPI;

@RestController
@RequestMapping("/c")
public class ClinicalController {
	@Autowired(required = true)
	ClinicalServiceAPI cService;
	
	@GetMapping("/{patientId}")
	public ResponseEntity<List<ClinicalDetails>> getAllClinicalAction(@PathVariable("patientId") long patientId) {
		System.out.println("in controller getall method");
		List<ClinicalDetails> c= cService.getClinicalByPatId(patientId);
		return c == null ? new ResponseEntity<>(HttpStatus.OK) : new ResponseEntity<List<ClinicalDetails>>(c, HttpStatus.OK);
	}
	
	/*
	 * @PostMapping("/{patientId}") public ResponseEntity<ClinicalDetails>
	 * insertAction(@PathVariable("patientId") long patientId,@RequestBody
	 * ClinicalDetails cd) { System.out.println(" in controller insert()  "); //
	 * throws InvalidTxnException{ cService.createClinical(patientId,cd); return new
	 * ResponseEntity<>(HttpStatus.CREATED); }
	 */
	
	/*
	 * @PutMapping("/{patientId}") public ResponseEntity<Patient>
	 * updateAction(@PathVariable("patientId") Long patientId, @RequestBody
	 * ClinicalDetails cd) { // throws InvalidTxnException{
	 * cService.updateClinicalByPatId(patientId,cd); return new
	 * ResponseEntity<>(HttpStatus.ACCEPTED); }
	 */
}
