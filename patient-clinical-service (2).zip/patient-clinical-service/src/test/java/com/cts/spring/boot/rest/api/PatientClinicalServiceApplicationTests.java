package com.cts.spring.boot.rest.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientClinicalServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
