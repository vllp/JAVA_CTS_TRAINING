package com.cts.spring.boot.data.jpa.demo2.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import javax.swing.text.DateFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.cts.spring.boot.data.jpa.demo2.entity.Employee;
import com.cts.spring.boot.data.jpa.demo2.service.EmployeeService;

@Component
public class EmployeeUI implements ApplicationRunner {

	@Autowired
	public Scanner kbin;

	@Autowired
	public EmployeeService empService;

	@Autowired
	public DateTimeFormatter dtFormatter;

	@Override
	public void run(ApplicationArguments args) throws Exception {

		Menu menu = null;
		Menu[] menus = Menu.values();

		while (menu != Menu.QUIT) {
			System.out.println("Menus");
			Arrays.stream(menus).map(m -> m.ordinal() + "\t" + m).forEach(System.out::println);
			System.out.print("Choice: ");
			int ch = kbin.nextInt();

			if (ch < 0 || ch >= menus.length) {
				System.out.println("Invlaid Choice");
				continue;
			}

			menu = menus[ch];

			switch (menu) {
			case LIST:
				doList();
				break;
			case ADD:
				doAdd();
				break;
			case DELETE:
				doDelete();
				break;
			case QUIT:
				System.out.println("App Terminated!");
				break;
			}
		}
	}

	private void doList() {
		List<Employee> emps = empService.getAll();

		if (emps.isEmpty()) {
			System.out.println("No records to display");
		} else {
			emps.stream().forEach(System.out::println);
		}

	}

	private void doAdd() {
		Employee emp = new Employee();

		System.out.print("Emp Name: ");
		emp.setEmpName(kbin.next());
		System.out.print("Joining Date(dd-MM-yy): ");
		emp.setJoinDate(LocalDate.parse(kbin.next(), dtFormatter));
		System.out.print("Emp Designation :");
		emp.setEmpDesig(kbin.next());
		System.out.print("Salary: ");
		emp.setEmpSal(kbin.nextDouble());

		empService.add(emp);
	}

	private void doDelete() {
		System.out.println("Emp Id: ");
		long empId = kbin.nextLong();

		empService.remove(empId);

	}

}
