package com.cts.spring.boot.data.jpa.demo2.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.spring.boot.data.jpa.demo2.entity.Employee;

public interface EmployeeRepos extends JpaRepository<Employee, Long>{
	

}
