package com.cts.spring.boot.data.jpa.demo2;

import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SpringBootDataJpaDemo2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDataJpaDemo2Application.class, args);
	}
	
	@Bean
	public Scanner scanner() {
		return new Scanner(System.in);
	}
	
	@Bean
	public DateTimeFormatter dtFormat() {
		return DateTimeFormatter.ofPattern("dd-MM-yy");
	}


}
