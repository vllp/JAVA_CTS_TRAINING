package com.cts.spring.boot.data.jpa.demo2.ui;

public enum Menu {
	LIST, ADD, DELETE, QUIT;
}
