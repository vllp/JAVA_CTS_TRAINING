package com.cts.spring.boot.data.jpa.demo2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.spring.boot.data.jpa.demo2.entity.Employee;
import com.cts.spring.boot.data.jpa.demo2.repo.EmployeeRepos;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepos empRepo;

	@Override
	public Employee getById(Long id) {
		return empRepo.findById(id).orElse(null);
	}

	@Override
	public List<Employee> getAll() {
		return empRepo.findAll();
	}

	@Override
	public Employee add(Employee emp) {
		return empRepo.save(emp);
	}

	@Override
	public void remove(Long id) {
		empRepo.deleteById(id);
	}
	

}
