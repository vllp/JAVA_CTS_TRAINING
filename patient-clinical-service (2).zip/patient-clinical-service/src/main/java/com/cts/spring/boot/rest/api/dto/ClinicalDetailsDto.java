package com.cts.spring.boot.rest.api.dto;

import java.time.LocalDate;

import com.cts.spring.boot.rest.api.entity.Patient;

public class ClinicalDetailsDto {

	private Long clinicalId;
	private String componentName;
	private Double componentValue;
	private LocalDate measuredDateTime;
	private Patient patient;

	public ClinicalDetailsDto() {
	}

	public ClinicalDetailsDto(Long clinicalId, String componentName, Double componentValue, LocalDate measuredDateTime,
			Patient patient) {
		super();
		this.clinicalId = clinicalId;
		this.componentName = componentName;
		this.componentValue = componentValue;
		this.measuredDateTime = measuredDateTime;
		this.patient = patient;
	}

	public Long getClinicalId() {
		return clinicalId;
	}

	public void setClinicalId(Long clinicalId) {
		this.clinicalId = clinicalId;
	}

	public String getComponentName() {
		return componentName;
	}

	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	public Double getComponentValue() {
		return componentValue;
	}

	public void setComponentValue(Double componentValue) {
		this.componentValue = componentValue;
	}

	public LocalDate getMeasuredDateTime() {
		return measuredDateTime;
	}

	public void setMeasuredDateTime(LocalDate measuredDateTime) {
		this.measuredDateTime = measuredDateTime;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}
}
