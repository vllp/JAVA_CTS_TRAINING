package com.cts.spring.boot.rest.api.services;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.spring.boot.rest.api.dto.ClinicalDetailsDto;
import com.cts.spring.boot.rest.api.entity.ClinicalDetails;
import com.cts.spring.boot.rest.api.entity.Patient;
import com.cts.spring.boot.rest.api.repos.ClinicalRepo;
import com.cts.spring.boot.rest.api.repos.PatientRepo;

@Service
public class ClinicalServiceAPIImpl implements ClinicalServiceAPI {
	@Autowired
	ClinicalRepo clinicalRepo;
	@Autowired
	PatientRepo patientRepo;

	@Override
	public List<ClinicalDetails> getClinicalByPatId(Long patientId) {

		return (List<ClinicalDetails>) clinicalRepo.findById(patientId).orElse(null);
	}

	@Override
	public ClinicalDetails createClinical(Long patientId, ClinicalDetailsDto cdto) {
		ClinicalDetails cd = new ClinicalDetails();
		cd.setComponentName(cdto.getComponentName());
		cd.setComponentValue(cdto.getComponentValue());
		cd.setMeasuredDateTime(cdto.getMeasuredDateTime());

		System.out.println("in service create()");

		Patient p = patientRepo.findById(patientId).orElse(null);

		System.out.println("in service ------" + p.toString());

		Set<ClinicalDetails> c = new HashSet<>();
		c.add(cd);

		if (p != null)
			p.setClinicalDetails(c);
		cd.setPatient(p);
		//patientRepo.save(p);

		System.out.println("in service ----clinicalDetails-----" + cdto);

		return clinicalRepo.save(cd);

		/*
		 * Patient p = patientRepo.findById(patientId).orElse(null); if (p != null) {
		 * ClinicalDetails cd = new ClinicalDetails(); double bmi = 0.0;
		 * Set<ClinicalDetails> clinDetails = p.getClinicalDetails();
		 * System.out.println(clinDetails);
		 * cd.setComponentName(clinicalDetails.getComponentName());
		 * cd.setComponentValue(clinicalDetails.getComponentValue());
		 * 
		 * if (clinDetails.size() > 0) { // Set<ClinicalDetails> details= //
		 * clinDetails.stream().filter(e->e.getComponentName().equals("HEIGHT"|"WEIGHT")
		 * ).collect(Collectors.toSet());
		 * 
		 * String compName = clinDetails.stream().findFirst().get().getComponentName();
		 * double compValue =
		 * clinDetails.stream().findFirst().get().getComponentValue(); if
		 * (compName.equalsIgnoreCase("Height")) { bmi =
		 * clinicalDetails.getComponentValue() / (compValue * compValue); } else { bmi =
		 * compValue / (clinicalDetails.getComponentValue() *
		 * clinicalDetails.getComponentValue()); } cd.setComponentName("BMI");
		 * cd.setComponentValue(bmi); }
		 * 
		 * cd.setMeasuredDateTime(clinicalDetails.getMeasuredDateTime());
		 * cd.setPatient(p);
		 * 
		 * p.getClinicalDetails().add(cd); patientRepo.save(p); return
		 * clinicalRepo.save(cd); } else { return null; }
		 */

	}

	/*
	 * @Override public ClinicalDetails createClinical(Long patientId,
	 * List<ClinicalDetails> clinicalDetails) { List<ClinicalDetails> cd = new
	 * ArrayList<ClinicalDetails>(); for(ClinicalDetails c : clinicalDetails){
	 * cd.add(new ClinicalDetails(c.getClinicalId(),c.getComponentName(),
	 * c.getComponentValue(),c.getMeasuredDateTime(),c.getPatient())); } cd.add(new
	 * ClinicalDetails()) cd.setComponentName(clinicalDetails.getComponentName());
	 * cd.setComponentValue(clinicalDetails.getComponentValue());
	 * cd.setMeasuredDateTime(clinicalDetails.getMeasuredDateTime());
	 * 
	 * 
	 * System.out.println("in service create()");
	 * 
	 * Patient p = patientRepo.findById(patientId).orElse(null);
	 * 
	 * System.out.println("in service ------"+p.toString());
	 * 
	 * 
	 * // if (p != null) p.getClinicalDetails().add(cd);
	 * 
	 * // patientRepo.save(p); //cd.setPatient(p);
	 * 
	 * System.out.println("in service ----clinicalDetails-----"+cd.toString());
	 * 
	 * return clinicalRepo.saveAll();
	 * 
	 * 
	 * 
	 * }
	 */

	@Override
	public ClinicalDetails updateClinicalByPatId(Long pId, ClinicalDetails clinicalDetails, Patient p) {
		/*
		 * //Set<ClinicalDetails> cd = (Set<ClinicalDetails>)
		 * clinicalRepo.findById(pId).orElse(null); Patient
		 * pat=patientRepo.findById(pId).orElse(p);
		 * 
		 * 
		 * Double totalDebits = et.stream().filter(e ->
		 * e.getTransType().matches("DEBIT"))
		 * .mapToDouble(EmployeeTransaction::getTransAmount).sum();
		 * 
		 * //
		 * txns.stream().filter(t->t.getType()==type).map(Txn::getAmount).reduce((s1,s2)
		 * ->s1+s2).orElse(0.0);
		 * 
		 * //cd.stream().filter(cd->cd.getComponentName()!=ComponentName.BMI).map(
		 * ClinicalDetails::getComponentValue).re
		 * //cd.setComponentName(clinicalDetails.getComponentName());
		 * //cd.setComponentValue(clinicalDetails.getComponentValue()); //
		 * cd.setMeasuredDateTime(clinicalDetails.getMeasuredDateTime());
		 * p.setClinicalDetails(cd); p.s return clinicalRepo.save(cd);
		 * 
		 */
		return null;
	}

}
