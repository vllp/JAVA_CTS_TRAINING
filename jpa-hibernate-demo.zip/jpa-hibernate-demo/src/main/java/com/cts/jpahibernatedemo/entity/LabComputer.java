package com.cts.jpahibernatedemo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="lab_computer")
public class LabComputer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long asserId;
	private String computerConfig;
	
	@OneToOne
	@JoinColumn
	private Trainee owner;

	public Long getAsserId() {
		return asserId;
	}

	public void setAsserId(Long asserId) {
		this.asserId = asserId;
	}

	public String getComputerConfig() {
		return computerConfig;
	}

	public void setComputerConfig(String computerConfig) {
		this.computerConfig = computerConfig;
	}

	public Trainee getOwner() {
		return owner;
	}

	public void setOwner(Trainee owner) {
		this.owner = owner;
	}

	public LabComputer(Long asserId, String computerConfig, Trainee owner) {
		super();
		this.asserId = asserId;
		this.computerConfig = computerConfig;
		this.owner = owner;
	}

	@Override
	public String toString() {
		return "LabComputer [asserId=" + asserId + ", computerConfig=" + computerConfig + ", owner=" + owner
				+ ", toString()=" + super.toString() + "]";
	}

}
