package com.cts.jpahibernatedemo.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cts.jpahibernatedemo.entity.AcademicHead;
import com.cts.jpahibernatedemo.entity.Address;
import com.cts.jpahibernatedemo.entity.ContractTrainer;
import com.cts.jpahibernatedemo.entity.Trainer;

public class AppImplInheritance {

	public static void main(String[] args) {
		EntityManager em = Persistence.createEntityManagerFactory("mysqlPU").createEntityManager();
		EntityTransaction et = em.getTransaction();

		et.begin();
		em.persist(new Trainer(123L, "Revathi", new Address("flat201", "vij", "ap"), "java", 23456.0));
		em.persist(new ContractTrainer(234L, "Gani", new Address("flat 20", "gun", "ap"), ".net", 567.0, 34.0));
		em.persist(new AcademicHead(567L, "lally", new Address("flat 34", "EGD", "ap"), "Hibernate", 5678.0, 654.0));
		et.commit();
		em.clear();
	}

}
