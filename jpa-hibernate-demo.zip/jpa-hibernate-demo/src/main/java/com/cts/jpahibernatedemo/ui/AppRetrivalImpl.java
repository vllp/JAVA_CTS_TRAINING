package com.cts.jpahibernatedemo.ui;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cts.jpahibernatedemo.entity.AcademicHead;
import com.cts.jpahibernatedemo.entity.Address;
import com.cts.jpahibernatedemo.entity.ContractTrainer;
import com.cts.jpahibernatedemo.entity.Trainee;
import com.cts.jpahibernatedemo.entity.Trainer;

public class AppRetrivalImpl {

	public static void main(String[] args) {
		EntityManager em = Persistence.createEntityManagerFactory("mysqlPU").createEntityManager();
		// EntityTransaction et = em.getTransaction();
		// et.begin();
		System.out.println("----     0     -------");

		System.out.println(em.find(Trainer.class, 123l));
		System.out.println("-----    1     ------");

		TypedQuery<Trainer> q1 = em.createQuery("SELECT t FROM Trainer t", Trainer.class);
		q1.getResultStream().forEach(System.out::println);

		System.out.println("------     2     -----");

		TypedQuery<String> qry2 = em.createQuery("SELECT t.fullName FROM Trainer t", String.class);
		qry2.getResultStream().forEach(System.out::println);

		System.out.println("------     3      -----");

		Query q3 = em.createQuery("SELECT t.trainerId, t.fullName FROM Trainer t");

		for (Object r : q3.getResultList()) {
			Object[] record = (Object[]) r;
			System.out.println(record[0] + "\t" + record[1]);
		}

		System.out.println("------     4      -----");

		TypedQuery<Trainee> q4 = em.createQuery("SELECT t FROM Trainee t WHERE t.traineeAddress.city=:city",
				Trainee.class);
		q4.setParameter("city", "vps");
		q4.getResultStream().forEach(System.out::println);

		System.out.println("------     5      -----");

		Query qry5 = em.createQuery("SELECT t.traineeName,c.crName FROM Trainee t INNER JOIN Course c ON t.course=c");
		for (Object row : qry5.getResultList()) {
			Object[] record = (Object[]) row;
			System.out.println(record[0] + "\t" + record[1]);
		}

		System.out.println("-------   6     ---------");

		Query qry6 = em.createQuery("SELECT DISTINCT t.traineeName,t.course.crName FROM Trainee t");
		// System.out.println(qry6.getResultList());
		for (Object row : qry6.getResultList()) {
			Object[] record = (Object[]) row;
			System.out.println(record[0] + "\t" + record[1]);
		}
		System.out.println("---------      7       -------------");
		System.out.println("-------    using group by    \r\n"
				+ "how do u work with groupby clause want to retrive course and no of trainees in each couse.----------");
		Query qry7 = em
				.createQuery(" SELECT DISTINCT t.course.crName, COUNT(t.traineeName)FROM Trainee t GROUP BY t.course ");

		for (Object row : qry7.getResultList()) {
			Object[] record = (Object[]) row;
			System.out.println(record[0] + "\t" + record[1]);
		}
		System.out.println("---------      8       -------------");
		// et.commit();
		em.clear();
	}

}
