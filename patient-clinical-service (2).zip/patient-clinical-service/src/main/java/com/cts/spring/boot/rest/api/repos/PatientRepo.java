package com.cts.spring.boot.rest.api.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.spring.boot.rest.api.entity.Patient;

public interface PatientRepo extends JpaRepository<Patient, Long>{

}
